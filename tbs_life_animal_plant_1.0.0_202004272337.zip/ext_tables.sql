#
# Table structure for table 'tx_tbslifeanimalplant_domain_model_lebensweltenubersicht'
#
CREATE TABLE tx_tbslifeanimalplant_domain_model_lebensweltenubersicht (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	name varchar(255) DEFAULT '' NOT NULL,
	header_image int(11) unsigned NOT NULL default '0',
	title_gallery varchar(255) DEFAULT '' NOT NULL,
	images int(11) unsigned NOT NULL default '0',
	description text,
	space varchar(255) DEFAULT '' NOT NULL,
	species_animal varchar(255) DEFAULT '' NOT NULL,
	species_plant varchar(255) DEFAULT '' NOT NULL,
	business_time varchar(255) DEFAULT '' NOT NULL,
	teaser_description text,
	animals int(11) unsigned DEFAULT '0' NOT NULL,
	plants int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);

#
# Table structure for table 'tx_tbslifeanimalplant_domain_model_tiereubersicht'
#
CREATE TABLE tx_tbslifeanimalplant_domain_model_tiereubersicht (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	name varchar(255) DEFAULT '' NOT NULL,
	header_image int(11) unsigned NOT NULL default '0',
	title_gallery varchar(255) DEFAULT '' NOT NULL,
	images int(11) unsigned NOT NULL default '0',
	description text,
	species int(11) DEFAULT '0' NOT NULL,
	habitat int(11) DEFAULT '0' NOT NULL,
	scientific_name varchar(255) DEFAULT '' NOT NULL,
	systematics varchar(255) DEFAULT '' NOT NULL,
	area varchar(255) DEFAULT '' NOT NULL,
	distribution varchar(255) DEFAULT '' NOT NULL,
	food varchar(255) DEFAULT '' NOT NULL,
	reproduction varchar(255) DEFAULT '' NOT NULL,
	structure varchar(255) DEFAULT '' NOT NULL,
	livestock varchar(255) DEFAULT '' NOT NULL,
	specials varchar(255) DEFAULT '' NOT NULL,
	sponsorship varchar(255) DEFAULT '' NOT NULL,
	lifeworld int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);

#
# Table structure for table 'tx_tbslifeanimalplant_domain_model_pflanzenarten'
#
CREATE TABLE tx_tbslifeanimalplant_domain_model_pflanzenarten (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	name varchar(255) DEFAULT '' NOT NULL,
	header_image int(11) unsigned NOT NULL default '0',
	title_gallery varchar(255) DEFAULT '' NOT NULL,
	images int(11) unsigned NOT NULL default '0',
	description text,
	category int(11) DEFAULT '0' NOT NULL,
	scientific_name varchar(255) DEFAULT '' NOT NULL,
	family varchar(255) DEFAULT '' NOT NULL,
	origin varchar(255) DEFAULT '' NOT NULL,
	exhibition_time varchar(255) DEFAULT '' NOT NULL,
	flowering_time varchar(255) DEFAULT '' NOT NULL,
	sponsorship varchar(255) DEFAULT '' NOT NULL,
	lifeworld int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);

#
# Table structure for table 'tx_tbslifeanimalplant_lebensweltenubersicht_tiereubersicht_mm'
#
CREATE TABLE tx_tbslifeanimalplant_lebensweltenubersicht_tiereubersicht_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid_local,uid_foreign),
	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tx_tbslifeanimalplant_lebensweltenubersicht_pflanzenarten_mm'
#
CREATE TABLE tx_tbslifeanimalplant_lebensweltenubersicht_pflanzenarten_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid_local,uid_foreign),
	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tx_tbslifeanimalplant_tiereubersicht_lebensweltenubersicht_mm'
#
CREATE TABLE tx_tbslifeanimalplant_tiereubersicht_lebensweltenubersicht_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid_local,uid_foreign),
	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tx_tbslifeanimalplant_pflanzenarten_lebensweltenubersicht_mm'
#
CREATE TABLE tx_tbslifeanimalplant_pflanzenarten_lebensweltenubersicht_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid_local,uid_foreign),
	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);
