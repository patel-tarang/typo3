<?php
namespace Tbs\TbsLifeAnimalPlant\Controller;

/***
 *
 * This file is part of the "TBS Life animal plant" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * PflanzenartenController
 */
class PflanzenartenController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * pflanzenartenRepository
     *
     * @var \Tbs\TbsLifeAnimalPlant\Domain\Repository\PflanzenartenRepository
     * @inject
     */
    protected $pflanzenartenRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $pflanzenartens = $this->pflanzenartenRepository->findAll();
        $this->view->assign('pflanzenartens', $pflanzenartens);
    }

    /**
     * action show
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten $pflanzenarten
     * @return void
     */
    public function showAction(\Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten $pflanzenarten)
    {
        $this->view->assign('pflanzenarten', $pflanzenarten);
    }
}
