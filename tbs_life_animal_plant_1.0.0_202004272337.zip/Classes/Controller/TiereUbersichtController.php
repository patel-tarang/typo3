<?php
namespace Tbs\TbsLifeAnimalPlant\Controller;

/***
 *
 * This file is part of the "TBS Life animal plant" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * TiereUbersichtController
 */
class TiereUbersichtController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * tiereUbersichtRepository
     *
     * @var \Tbs\TbsLifeAnimalPlant\Domain\Repository\TiereUbersichtRepository
     * @inject
     */
    protected $tiereUbersichtRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $tiereUbersichts = $this->tiereUbersichtRepository->findAll();
        $this->view->assign('tiereUbersichts', $tiereUbersichts);
    }

    /**
     * action show
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht $tiereUbersicht
     * @return void
     */
    public function showAction(\Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht $tiereUbersicht)
    {
        $this->view->assign('tiereUbersicht', $tiereUbersicht);
    }
}
