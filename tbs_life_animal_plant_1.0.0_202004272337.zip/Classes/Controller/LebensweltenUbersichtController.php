<?php
namespace Tbs\TbsLifeAnimalPlant\Controller;

/***
 *
 * This file is part of the "TBS Life animal plant" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * LebensweltenUbersichtController
 */
class LebensweltenUbersichtController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * lebensweltenUbersichtRepository
     *
     * @var \Tbs\TbsLifeAnimalPlant\Domain\Repository\LebensweltenUbersichtRepository
     * @inject
     */
    protected $lebensweltenUbersichtRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $lebensweltenUbersichts = $this->lebensweltenUbersichtRepository->findAll();
        $this->view->assign('lebensweltenUbersichts', $lebensweltenUbersichts);
    }

    /**
     * action show
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht $lebensweltenUbersicht
     * @return void
     */
    public function showAction(\Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht $lebensweltenUbersicht)
    {
        $this->view->assign('lebensweltenUbersicht', $lebensweltenUbersicht);
    }
}
