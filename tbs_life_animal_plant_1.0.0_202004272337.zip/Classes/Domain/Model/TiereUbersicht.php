<?php
namespace Tbs\TbsLifeAnimalPlant\Domain\Model;

/***
 *
 * This file is part of the "TBS Life animal plant" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * TiereUbersicht
 */
class TiereUbersicht extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * name
     *
     * @var string
     */
    protected $name = '';

    /**
     * headerImage
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $headerImage = null;

    /**
     * titleGallery
     *
     * @var string
     */
    protected $titleGallery = '';

    /**
     * images
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $images = null;

    /**
     * description
     *
     * @var string
     */
    protected $description = '';

    /**
     * species
     *
     * @var int
     */
    protected $species = 0;

    /**
     * habitat
     *
     * @var int
     */
    protected $habitat = 0;

    /**
     * scientificName
     *
     * @var string
     */
    protected $scientificName = '';

    /**
     * systematics
     *
     * @var string
     */
    protected $systematics = '';

    /**
     * area
     *
     * @var string
     */
    protected $area = '';

    /**
     * distribution
     *
     * @var string
     */
    protected $distribution = '';

    /**
     * food
     *
     * @var string
     */
    protected $food = '';

    /**
     * reproduction
     *
     * @var string
     */
    protected $reproduction = '';

    /**
     * structure
     *
     * @var string
     */
    protected $structure = '';

    /**
     * livestock
     *
     * @var string
     */
    protected $livestock = '';

    /**
     * specials
     *
     * @var string
     */
    protected $specials = '';

    /**
     * sponsorship
     *
     * @var string
     */
    protected $sponsorship = '';

    /**
     * lifeworld
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht>
     */
    protected $lifeworld = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->lifeworld = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the name
     *
     * @return string $name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Sets the name
     *
     * @param string $name
     * @return void
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * Returns the headerImage
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $headerImage
     */
    public function getHeaderImage()
    {
        return $this->headerImage;
    }

    /**
     * Sets the headerImage
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $headerImage
     * @return void
     */
    public function setHeaderImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $headerImage)
    {
        $this->headerImage = $headerImage;
    }

    /**
     * Returns the titleGallery
     *
     * @return string $titleGallery
     */
    public function getTitleGallery()
    {
        return $this->titleGallery;
    }

    /**
     * Sets the titleGallery
     *
     * @param string $titleGallery
     * @return void
     */
    public function setTitleGallery($titleGallery)
    {
        $this->titleGallery = $titleGallery;
    }

    /**
     * Returns the images
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $images
     */
    public function getImages()
    {
        return $this->images;
    }

    /**
     * Sets the images
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $images
     * @return void
     */
    public function setImages(\TYPO3\CMS\Extbase\Domain\Model\FileReference $images)
    {
        $this->images = $images;
    }

    /**
     * Returns the description
     *
     * @return string $description
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Sets the description
     *
     * @param string $description
     * @return void
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * Returns the species
     *
     * @return int $species
     */
    public function getSpecies()
    {
        return $this->species;
    }

    /**
     * Sets the species
     *
     * @param int $species
     * @return void
     */
    public function setSpecies($species)
    {
        $this->species = $species;
    }

    /**
     * Returns the habitat
     *
     * @return int $habitat
     */
    public function getHabitat()
    {
        return $this->habitat;
    }

    /**
     * Sets the habitat
     *
     * @param int $habitat
     * @return void
     */
    public function setHabitat($habitat)
    {
        $this->habitat = $habitat;
    }

    /**
     * Returns the scientificName
     *
     * @return string $scientificName
     */
    public function getScientificName()
    {
        return $this->scientificName;
    }

    /**
     * Sets the scientificName
     *
     * @param string $scientificName
     * @return void
     */
    public function setScientificName($scientificName)
    {
        $this->scientificName = $scientificName;
    }

    /**
     * Returns the systematics
     *
     * @return string $systematics
     */
    public function getSystematics()
    {
        return $this->systematics;
    }

    /**
     * Sets the systematics
     *
     * @param string $systematics
     * @return void
     */
    public function setSystematics($systematics)
    {
        $this->systematics = $systematics;
    }

    /**
     * Returns the area
     *
     * @return string $area
     */
    public function getArea()
    {
        return $this->area;
    }

    /**
     * Sets the area
     *
     * @param string $area
     * @return void
     */
    public function setArea($area)
    {
        $this->area = $area;
    }

    /**
     * Returns the distribution
     *
     * @return string $distribution
     */
    public function getDistribution()
    {
        return $this->distribution;
    }

    /**
     * Sets the distribution
     *
     * @param string $distribution
     * @return void
     */
    public function setDistribution($distribution)
    {
        $this->distribution = $distribution;
    }

    /**
     * Returns the food
     *
     * @return string $food
     */
    public function getFood()
    {
        return $this->food;
    }

    /**
     * Sets the food
     *
     * @param string $food
     * @return void
     */
    public function setFood($food)
    {
        $this->food = $food;
    }

    /**
     * Returns the reproduction
     *
     * @return string $reproduction
     */
    public function getReproduction()
    {
        return $this->reproduction;
    }

    /**
     * Sets the reproduction
     *
     * @param string $reproduction
     * @return void
     */
    public function setReproduction($reproduction)
    {
        $this->reproduction = $reproduction;
    }

    /**
     * Returns the structure
     *
     * @return string $structure
     */
    public function getStructure()
    {
        return $this->structure;
    }

    /**
     * Sets the structure
     *
     * @param string $structure
     * @return void
     */
    public function setStructure($structure)
    {
        $this->structure = $structure;
    }

    /**
     * Returns the livestock
     *
     * @return string $livestock
     */
    public function getLivestock()
    {
        return $this->livestock;
    }

    /**
     * Sets the livestock
     *
     * @param string $livestock
     * @return void
     */
    public function setLivestock($livestock)
    {
        $this->livestock = $livestock;
    }

    /**
     * Returns the specials
     *
     * @return string $specials
     */
    public function getSpecials()
    {
        return $this->specials;
    }

    /**
     * Sets the specials
     *
     * @param string $specials
     * @return void
     */
    public function setSpecials($specials)
    {
        $this->specials = $specials;
    }

    /**
     * Returns the sponsorship
     *
     * @return string $sponsorship
     */
    public function getSponsorship()
    {
        return $this->sponsorship;
    }

    /**
     * Sets the sponsorship
     *
     * @param string $sponsorship
     * @return void
     */
    public function setSponsorship($sponsorship)
    {
        $this->sponsorship = $sponsorship;
    }

    /**
     * Adds a LebensweltenUbersicht
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht $lifeworld
     * @return void
     */
    public function addLifeworld(\Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht $lifeworld)
    {
        $this->lifeworld->attach($lifeworld);
    }

    /**
     * Removes a LebensweltenUbersicht
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht $lifeworldToRemove The LebensweltenUbersicht to be removed
     * @return void
     */
    public function removeLifeworld(\Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht $lifeworldToRemove)
    {
        $this->lifeworld->detach($lifeworldToRemove);
    }

    /**
     * Returns the lifeworld
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht> $lifeworld
     */
    public function getLifeworld()
    {
        return $this->lifeworld;
    }

    /**
     * Sets the lifeworld
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht> $lifeworld
     * @return void
     */
    public function setLifeworld(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $lifeworld)
    {
        $this->lifeworld = $lifeworld;
    }
}
