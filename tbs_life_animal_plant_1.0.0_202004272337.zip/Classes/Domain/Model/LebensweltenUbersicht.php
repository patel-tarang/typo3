<?php
namespace Tbs\TbsLifeAnimalPlant\Domain\Model;

/***
 *
 * This file is part of the "TBS Life animal plant" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * LebensweltenUbersicht
 */
class LebensweltenUbersicht extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * name
     *
     * @var string
     */
    protected $name = '';

    /**
     * headerImage
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $headerImage = null;

    /**
     * titleGallery
     *
     * @var string
     */
    protected $titleGallery = '';

    /**
     * images
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $images = null;

    /**
     * description
     *
     * @var string
     */
    protected $description = '';

    /**
     * space
     *
     * @var string
     */
    protected $space = '';

    /**
     * speciesAnimal
     *
     * @var string
     */
    protected $speciesAnimal = '';

    /**
     * speciesPlant
     *
     * @var string
     */
    protected $speciesPlant = '';

    /**
     * businessTime
     *
     * @var string
     */
    protected $businessTime = '';

    /**
     * teaserDescription
     *
     * @var string
     */
    protected $teaserDescription = '';

    /**
     * animals
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht>
     */
    protected $animals = null;

    /**
     * plants
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten>
     */
    protected $plants = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->animals = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->plants = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the name
     *
     * @return string $name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Sets the name
     *
     * @param string $name
     * @return void
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * Returns the headerImage
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $headerImage
     */
    public function getHeaderImage()
    {
        return $this->headerImage;
    }

    /**
     * Sets the headerImage
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $headerImage
     * @return void
     */
    public function setHeaderImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $headerImage)
    {
        $this->headerImage = $headerImage;
    }

    /**
     * Returns the titleGallery
     *
     * @return string $titleGallery
     */
    public function getTitleGallery()
    {
        return $this->titleGallery;
    }

    /**
     * Sets the titleGallery
     *
     * @param string $titleGallery
     * @return void
     */
    public function setTitleGallery($titleGallery)
    {
        $this->titleGallery = $titleGallery;
    }

    /**
     * Returns the images
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $images
     */
    public function getImages()
    {
        return $this->images;
    }

    /**
     * Sets the images
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $images
     * @return void
     */
    public function setImages(\TYPO3\CMS\Extbase\Domain\Model\FileReference $images)
    {
        $this->images = $images;
    }

    /**
     * Returns the description
     *
     * @return string $description
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Sets the description
     *
     * @param string $description
     * @return void
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * Returns the space
     *
     * @return string $space
     */
    public function getSpace()
    {
        return $this->space;
    }

    /**
     * Sets the space
     *
     * @param string $space
     * @return void
     */
    public function setSpace($space)
    {
        $this->space = $space;
    }

    /**
     * Returns the speciesAnimal
     *
     * @return string $speciesAnimal
     */
    public function getSpeciesAnimal()
    {
        return $this->speciesAnimal;
    }

    /**
     * Sets the speciesAnimal
     *
     * @param string $speciesAnimal
     * @return void
     */
    public function setSpeciesAnimal($speciesAnimal)
    {
        $this->speciesAnimal = $speciesAnimal;
    }

    /**
     * Returns the speciesPlant
     *
     * @return string $speciesPlant
     */
    public function getSpeciesPlant()
    {
        return $this->speciesPlant;
    }

    /**
     * Sets the speciesPlant
     *
     * @param string $speciesPlant
     * @return void
     */
    public function setSpeciesPlant($speciesPlant)
    {
        $this->speciesPlant = $speciesPlant;
    }

    /**
     * Returns the businessTime
     *
     * @return string $businessTime
     */
    public function getBusinessTime()
    {
        return $this->businessTime;
    }

    /**
     * Sets the businessTime
     *
     * @param string $businessTime
     * @return void
     */
    public function setBusinessTime($businessTime)
    {
        $this->businessTime = $businessTime;
    }

    /**
     * Returns the teaserDescription
     *
     * @return string $teaserDescription
     */
    public function getTeaserDescription()
    {
        return $this->teaserDescription;
    }

    /**
     * Sets the teaserDescription
     *
     * @param string $teaserDescription
     * @return void
     */
    public function setTeaserDescription($teaserDescription)
    {
        $this->teaserDescription = $teaserDescription;
    }

    /**
     * Adds a TiereUbersicht
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht $animal
     * @return void
     */
    public function addAnimal(\Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht $animal)
    {
        $this->animals->attach($animal);
    }

    /**
     * Removes a TiereUbersicht
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht $animalToRemove The TiereUbersicht to be removed
     * @return void
     */
    public function removeAnimal(\Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht $animalToRemove)
    {
        $this->animals->detach($animalToRemove);
    }

    /**
     * Returns the animals
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht> $animals
     */
    public function getAnimals()
    {
        return $this->animals;
    }

    /**
     * Sets the animals
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht> $animals
     * @return void
     */
    public function setAnimals(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $animals)
    {
        $this->animals = $animals;
    }

    /**
     * Adds a Pflanzenarten
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten $plant
     * @return void
     */
    public function addPlant(\Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten $plant)
    {
        $this->plants->attach($plant);
    }

    /**
     * Removes a Pflanzenarten
     *
     * @param \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten $plantToRemove The Pflanzenarten to be removed
     * @return void
     */
    public function removePlant(\Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten $plantToRemove)
    {
        $this->plants->detach($plantToRemove);
    }

    /**
     * Returns the plants
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten> $plants
     */
    public function getPlants()
    {
        return $this->plants;
    }

    /**
     * Sets the plants
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten> $plants
     * @return void
     */
    public function setPlants(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $plants)
    {
        $this->plants = $plants;
    }
}
