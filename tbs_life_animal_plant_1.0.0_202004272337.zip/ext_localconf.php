<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsLifeAnimalPlant',
            'Tbslebensweltenubersicht',
            [
                'LebensweltenUbersicht' => 'list, show',
                'TiereUbersicht' => 'list, show',
                'Pflanzenarten' => 'list, show'
            ],
            // non-cacheable actions
            [
                'LebensweltenUbersicht' => '',
                'TiereUbersicht' => '',
                'Pflanzenarten' => ''
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsLifeAnimalPlant',
            'Tbstiereubersicht',
            [
                'LebensweltenUbersicht' => 'list, show',
                'TiereUbersicht' => 'list, show',
                'Pflanzenarten' => 'list, show'
            ],
            // non-cacheable actions
            [
                'LebensweltenUbersicht' => '',
                'TiereUbersicht' => '',
                'Pflanzenarten' => ''
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsLifeAnimalPlant',
            'Tbspflanzenarten',
            [
                'LebensweltenUbersicht' => 'list, show',
                'TiereUbersicht' => 'list, show',
                'Pflanzenarten' => 'list, show'
            ],
            // non-cacheable actions
            [
                'LebensweltenUbersicht' => '',
                'TiereUbersicht' => '',
                'Pflanzenarten' => ''
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    tbslebensweltenubersicht {
                        iconIdentifier = tbs_life_animal_plant-plugin-tbslebensweltenubersicht
                        title = LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbs_life_animal_plant_tbslebensweltenubersicht.name
                        description = LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbs_life_animal_plant_tbslebensweltenubersicht.description
                        tt_content_defValues {
                            CType = list
                            list_type = tbslifeanimalplant_tbslebensweltenubersicht
                        }
                    }
                    tbstiereubersicht {
                        iconIdentifier = tbs_life_animal_plant-plugin-tbstiereubersicht
                        title = LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbs_life_animal_plant_tbstiereubersicht.name
                        description = LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbs_life_animal_plant_tbstiereubersicht.description
                        tt_content_defValues {
                            CType = list
                            list_type = tbslifeanimalplant_tbstiereubersicht
                        }
                    }
                    tbspflanzenarten {
                        iconIdentifier = tbs_life_animal_plant-plugin-tbspflanzenarten
                        title = LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbs_life_animal_plant_tbspflanzenarten.name
                        description = LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbs_life_animal_plant_tbspflanzenarten.description
                        tt_content_defValues {
                            CType = list
                            list_type = tbslifeanimalplant_tbspflanzenarten
                        }
                    }
                }
                show = *
            }
       }'
    );
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
		
			$iconRegistry->registerIcon(
				'tbs_life_animal_plant-plugin-tbslebensweltenubersicht',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:tbs_life_animal_plant/Resources/Public/Icons/user_plugin_tbslebensweltenubersicht.svg']
			);
		
			$iconRegistry->registerIcon(
				'tbs_life_animal_plant-plugin-tbstiereubersicht',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:tbs_life_animal_plant/Resources/Public/Icons/user_plugin_tbstiereubersicht.svg']
			);
		
			$iconRegistry->registerIcon(
				'tbs_life_animal_plant-plugin-tbspflanzenarten',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:tbs_life_animal_plant/Resources/Public/Icons/user_plugin_tbspflanzenarten.svg']
			);
		
    }
);
