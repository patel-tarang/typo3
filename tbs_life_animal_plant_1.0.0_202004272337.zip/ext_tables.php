<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsLifeAnimalPlant',
            'Tbslebensweltenubersicht',
            'Lebenswelten Übersicht'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsLifeAnimalPlant',
            'Tbstiereubersicht',
            'Tiere Übersicht'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsLifeAnimalPlant',
            'Tbspflanzenarten',
            'Pflanzenarten'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('tbs_life_animal_plant', 'Configuration/TypoScript', 'TBS Life animal plant');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_tbslifeanimalplant_domain_model_lebensweltenubersicht', 'EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_csh_tx_tbslifeanimalplant_domain_model_lebensweltenubersicht.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbslifeanimalplant_domain_model_lebensweltenubersicht');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_tbslifeanimalplant_domain_model_tiereubersicht', 'EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_csh_tx_tbslifeanimalplant_domain_model_tiereubersicht.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbslifeanimalplant_domain_model_tiereubersicht');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_tbslifeanimalplant_domain_model_pflanzenarten', 'EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_csh_tx_tbslifeanimalplant_domain_model_pflanzenarten.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbslifeanimalplant_domain_model_pflanzenarten');

    }
);
