
plugin.tx_tbslifeanimalplant_tbslebensweltenubersicht {
    view {
        # cat=plugin.tx_tbslifeanimalplant_tbslebensweltenubersicht/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:tbs_life_animal_plant/Resources/Private/Templates/
        # cat=plugin.tx_tbslifeanimalplant_tbslebensweltenubersicht/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:tbs_life_animal_plant/Resources/Private/Partials/
        # cat=plugin.tx_tbslifeanimalplant_tbslebensweltenubersicht/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:tbs_life_animal_plant/Resources/Private/Layouts/
    }
    persistence {
        # cat=plugin.tx_tbslifeanimalplant_tbslebensweltenubersicht//a; type=string; label=Default storage PID
        storagePid =
    }
}

plugin.tx_tbslifeanimalplant_tbstiereubersicht {
    view {
        # cat=plugin.tx_tbslifeanimalplant_tbstiereubersicht/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:tbs_life_animal_plant/Resources/Private/Templates/
        # cat=plugin.tx_tbslifeanimalplant_tbstiereubersicht/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:tbs_life_animal_plant/Resources/Private/Partials/
        # cat=plugin.tx_tbslifeanimalplant_tbstiereubersicht/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:tbs_life_animal_plant/Resources/Private/Layouts/
    }
    persistence {
        # cat=plugin.tx_tbslifeanimalplant_tbstiereubersicht//a; type=string; label=Default storage PID
        storagePid =
    }
}

plugin.tx_tbslifeanimalplant_tbspflanzenarten {
    view {
        # cat=plugin.tx_tbslifeanimalplant_tbspflanzenarten/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:tbs_life_animal_plant/Resources/Private/Templates/
        # cat=plugin.tx_tbslifeanimalplant_tbspflanzenarten/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:tbs_life_animal_plant/Resources/Private/Partials/
        # cat=plugin.tx_tbslifeanimalplant_tbspflanzenarten/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:tbs_life_animal_plant/Resources/Private/Layouts/
    }
    persistence {
        # cat=plugin.tx_tbslifeanimalplant_tbspflanzenarten//a; type=string; label=Default storage PID
        storagePid =
    }
}
