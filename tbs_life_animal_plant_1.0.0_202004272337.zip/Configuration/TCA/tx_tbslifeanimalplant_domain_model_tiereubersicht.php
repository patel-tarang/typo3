<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht',
        'label' => 'name',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'versioningWS' => true,
        'languageField' => 'sys_language_uid',
        'transOrigPointerField' => 'l10n_parent',
        'transOrigDiffSourceField' => 'l10n_diffsource',
        'delete' => 'deleted',
        'enablecolumns' => [
            'disabled' => 'hidden',
            'starttime' => 'starttime',
            'endtime' => 'endtime',
        ],
        'searchFields' => 'name,header_image,title_gallery,images,description,species,habitat,scientific_name,systematics,area,distribution,food,reproduction,structure,livestock,specials,sponsorship,lifeworld',
        'iconfile' => 'EXT:tbs_life_animal_plant/Resources/Public/Icons/tx_tbslifeanimalplant_domain_model_tiereubersicht.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'sys_language_uid, l10n_parent, l10n_diffsource, hidden, name, header_image, title_gallery, images, description, species, habitat, scientific_name, systematics, area, distribution, food, reproduction, structure, livestock, specials, sponsorship, lifeworld',
    ],
    'types' => [
        '1' => ['showitem' => 'sys_language_uid, l10n_parent, l10n_diffsource, hidden, name, header_image, title_gallery, images, description, species, habitat, scientific_name, systematics, area, distribution, food, reproduction, structure, livestock, specials, sponsorship, lifeworld, --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:tabs.access, starttime, endtime'],
    ],
    'columns' => [
        'sys_language_uid' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.language',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'special' => 'languages',
                'items' => [
                    [
                        'LLL:EXT:lang/locallang_general.xlf:LGL.allLanguages',
                        -1,
                        'flags-multiple'
                    ]
                ],
                'default' => 0,
            ],
        ],
        'l10n_parent' => [
            'displayCond' => 'FIELD:sys_language_uid:>:0',
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.l18n_parent',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'default' => 0,
                'items' => [
                    ['', 0],
                ],
                'foreign_table' => 'tx_tbslifeanimalplant_domain_model_tiereubersicht',
                'foreign_table_where' => 'AND tx_tbslifeanimalplant_domain_model_tiereubersicht.pid=###CURRENT_PID### AND tx_tbslifeanimalplant_domain_model_tiereubersicht.sys_language_uid IN (-1,0)',
            ],
        ],
        'l10n_diffsource' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        't3ver_label' => [
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.versionLabel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'max' => 255,
            ],
        ],
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'starttime' => [
            'exclude' => true,
            'behaviour' => [
                'allowLanguageSynchronization' => true
            ],
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.starttime',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 13,
                'eval' => 'datetime',
                'default' => 0,
            ],
        ],
        'endtime' => [
            'exclude' => true,
            'behaviour' => [
                'allowLanguageSynchronization' => true
            ],
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.endtime',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 13,
                'eval' => 'datetime',
                'default' => 0,
                'range' => [
                    'upper' => mktime(0, 0, 0, 1, 1, 2038)
                ],
            ],
        ],

        'name' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.name',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'header_image' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.header_image',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                'header_image',
                [
                    'appearance' => [
                        'createNewRelationLinkTitle' => 'LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:images.addFileReference'
                    ],
                    'foreign_types' => [
                        '0' => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_TEXT => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_AUDIO => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_VIDEO => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_APPLICATION => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ]
                    ],
                    'maxitems' => 1
                ],
                $GLOBALS['TYPO3_CONF_VARS']['GFX']['imagefile_ext']
            ),
        ],
        'title_gallery' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.title_gallery',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'images' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.images',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                'images',
                [
                    'appearance' => [
                        'createNewRelationLinkTitle' => 'LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:images.addFileReference'
                    ],
                    'foreign_types' => [
                        '0' => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_TEXT => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_AUDIO => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_VIDEO => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_APPLICATION => [
                            'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                            --palette--;;filePalette'
                        ]
                    ],
                    'maxitems' => 1
                ],
                $GLOBALS['TYPO3_CONF_VARS']['GFX']['imagefile_ext']
            ),
        ],
        'description' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.description',
            'config' => [
                'type' => 'text',
                'enableRichtext' => true,
                'richtextConfiguration' => 'default',
                'fieldControl' => [
                    'fullScreenRichtext' => [
                        'disabled' => false,
                    ],
                ],
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim',
            ],
            
        ],
        'species' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.species',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['-- Label --', 0],
                ],
                'size' => 1,
                'maxitems' => 1,
                'eval' => ''
            ],
        ],
        'habitat' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.habitat',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['-- Label --', 0],
                ],
                'size' => 1,
                'maxitems' => 1,
                'eval' => ''
            ],
        ],
        'scientific_name' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.scientific_name',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'systematics' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.systematics',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'area' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.area',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'distribution' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.distribution',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'food' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.food',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'reproduction' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.reproduction',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'structure' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.structure',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'livestock' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.livestock',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'specials' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.specials',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'sponsorship' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.sponsorship',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'lifeworld' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_life_animal_plant/Resources/Private/Language/locallang_db.xlf:tx_tbslifeanimalplant_domain_model_tiereubersicht.lifeworld',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingleBox',
                'foreign_table' => 'tx_tbslifeanimalplant_domain_model_lebensweltenubersicht',
                'MM' => 'tx_tbslifeanimalplant_tiereubersicht_lebensweltenubersicht_mm',
            ],
            
        ],
    
    ],
];
