<?php
namespace Tbs\TbsLifeAnimalPlant\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class TiereUbersichtTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getName()
        );
    }

    /**
     * @test
     */
    public function setNameForStringSetsName()
    {
        $this->subject->setName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'name',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHeaderImageReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getHeaderImage()
        );
    }

    /**
     * @test
     */
    public function setHeaderImageForFileReferenceSetsHeaderImage()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setHeaderImage($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'headerImage',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTitleGalleryReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTitleGallery()
        );
    }

    /**
     * @test
     */
    public function setTitleGalleryForStringSetsTitleGallery()
    {
        $this->subject->setTitleGallery('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'titleGallery',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getImagesReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getImages()
        );
    }

    /**
     * @test
     */
    public function setImagesForFileReferenceSetsImages()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setImages($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'images',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getDescriptionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getDescription()
        );
    }

    /**
     * @test
     */
    public function setDescriptionForStringSetsDescription()
    {
        $this->subject->setDescription('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'description',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSpeciesReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getSpecies()
        );
    }

    /**
     * @test
     */
    public function setSpeciesForIntSetsSpecies()
    {
        $this->subject->setSpecies(12);

        self::assertAttributeEquals(
            12,
            'species',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHabitatReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getHabitat()
        );
    }

    /**
     * @test
     */
    public function setHabitatForIntSetsHabitat()
    {
        $this->subject->setHabitat(12);

        self::assertAttributeEquals(
            12,
            'habitat',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getScientificNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getScientificName()
        );
    }

    /**
     * @test
     */
    public function setScientificNameForStringSetsScientificName()
    {
        $this->subject->setScientificName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'scientificName',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSystematicsReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSystematics()
        );
    }

    /**
     * @test
     */
    public function setSystematicsForStringSetsSystematics()
    {
        $this->subject->setSystematics('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'systematics',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getAreaReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getArea()
        );
    }

    /**
     * @test
     */
    public function setAreaForStringSetsArea()
    {
        $this->subject->setArea('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'area',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getDistributionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getDistribution()
        );
    }

    /**
     * @test
     */
    public function setDistributionForStringSetsDistribution()
    {
        $this->subject->setDistribution('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'distribution',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getFoodReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFood()
        );
    }

    /**
     * @test
     */
    public function setFoodForStringSetsFood()
    {
        $this->subject->setFood('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'food',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getReproductionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getReproduction()
        );
    }

    /**
     * @test
     */
    public function setReproductionForStringSetsReproduction()
    {
        $this->subject->setReproduction('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'reproduction',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getStructureReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getStructure()
        );
    }

    /**
     * @test
     */
    public function setStructureForStringSetsStructure()
    {
        $this->subject->setStructure('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'structure',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getLivestockReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getLivestock()
        );
    }

    /**
     * @test
     */
    public function setLivestockForStringSetsLivestock()
    {
        $this->subject->setLivestock('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'livestock',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSpecialsReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSpecials()
        );
    }

    /**
     * @test
     */
    public function setSpecialsForStringSetsSpecials()
    {
        $this->subject->setSpecials('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'specials',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSponsorshipReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSponsorship()
        );
    }

    /**
     * @test
     */
    public function setSponsorshipForStringSetsSponsorship()
    {
        $this->subject->setSponsorship('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'sponsorship',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getLifeworldReturnsInitialValueForLebensweltenUbersicht()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getLifeworld()
        );
    }

    /**
     * @test
     */
    public function setLifeworldForObjectStorageContainingLebensweltenUbersichtSetsLifeworld()
    {
        $lifeworld = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
        $objectStorageHoldingExactlyOneLifeworld = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneLifeworld->attach($lifeworld);
        $this->subject->setLifeworld($objectStorageHoldingExactlyOneLifeworld);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneLifeworld,
            'lifeworld',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addLifeworldToObjectStorageHoldingLifeworld()
    {
        $lifeworld = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
        $lifeworldObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $lifeworldObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($lifeworld));
        $this->inject($this->subject, 'lifeworld', $lifeworldObjectStorageMock);

        $this->subject->addLifeworld($lifeworld);
    }

    /**
     * @test
     */
    public function removeLifeworldFromObjectStorageHoldingLifeworld()
    {
        $lifeworld = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
        $lifeworldObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $lifeworldObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($lifeworld));
        $this->inject($this->subject, 'lifeworld', $lifeworldObjectStorageMock);

        $this->subject->removeLifeworld($lifeworld);
    }
}
