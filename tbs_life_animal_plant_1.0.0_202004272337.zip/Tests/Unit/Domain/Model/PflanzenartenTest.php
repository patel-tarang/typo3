<?php
namespace Tbs\TbsLifeAnimalPlant\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class PflanzenartenTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getName()
        );
    }

    /**
     * @test
     */
    public function setNameForStringSetsName()
    {
        $this->subject->setName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'name',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHeaderImageReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getHeaderImage()
        );
    }

    /**
     * @test
     */
    public function setHeaderImageForFileReferenceSetsHeaderImage()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setHeaderImage($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'headerImage',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTitleGalleryReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTitleGallery()
        );
    }

    /**
     * @test
     */
    public function setTitleGalleryForStringSetsTitleGallery()
    {
        $this->subject->setTitleGallery('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'titleGallery',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getImagesReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getImages()
        );
    }

    /**
     * @test
     */
    public function setImagesForFileReferenceSetsImages()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setImages($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'images',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getDescriptionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getDescription()
        );
    }

    /**
     * @test
     */
    public function setDescriptionForStringSetsDescription()
    {
        $this->subject->setDescription('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'description',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getCategoryReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getCategory()
        );
    }

    /**
     * @test
     */
    public function setCategoryForIntSetsCategory()
    {
        $this->subject->setCategory(12);

        self::assertAttributeEquals(
            12,
            'category',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getScientificNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getScientificName()
        );
    }

    /**
     * @test
     */
    public function setScientificNameForStringSetsScientificName()
    {
        $this->subject->setScientificName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'scientificName',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getFamilyReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFamily()
        );
    }

    /**
     * @test
     */
    public function setFamilyForStringSetsFamily()
    {
        $this->subject->setFamily('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'family',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getOriginReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getOrigin()
        );
    }

    /**
     * @test
     */
    public function setOriginForStringSetsOrigin()
    {
        $this->subject->setOrigin('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'origin',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getExhibitionTimeReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getExhibitionTime()
        );
    }

    /**
     * @test
     */
    public function setExhibitionTimeForStringSetsExhibitionTime()
    {
        $this->subject->setExhibitionTime('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'exhibitionTime',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getFloweringTimeReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFloweringTime()
        );
    }

    /**
     * @test
     */
    public function setFloweringTimeForStringSetsFloweringTime()
    {
        $this->subject->setFloweringTime('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'floweringTime',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSponsorshipReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSponsorship()
        );
    }

    /**
     * @test
     */
    public function setSponsorshipForStringSetsSponsorship()
    {
        $this->subject->setSponsorship('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'sponsorship',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getLifeworldReturnsInitialValueForLebensweltenUbersicht()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getLifeworld()
        );
    }

    /**
     * @test
     */
    public function setLifeworldForObjectStorageContainingLebensweltenUbersichtSetsLifeworld()
    {
        $lifeworld = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
        $objectStorageHoldingExactlyOneLifeworld = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneLifeworld->attach($lifeworld);
        $this->subject->setLifeworld($objectStorageHoldingExactlyOneLifeworld);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneLifeworld,
            'lifeworld',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addLifeworldToObjectStorageHoldingLifeworld()
    {
        $lifeworld = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
        $lifeworldObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $lifeworldObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($lifeworld));
        $this->inject($this->subject, 'lifeworld', $lifeworldObjectStorageMock);

        $this->subject->addLifeworld($lifeworld);
    }

    /**
     * @test
     */
    public function removeLifeworldFromObjectStorageHoldingLifeworld()
    {
        $lifeworld = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
        $lifeworldObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $lifeworldObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($lifeworld));
        $this->inject($this->subject, 'lifeworld', $lifeworldObjectStorageMock);

        $this->subject->removeLifeworld($lifeworld);
    }
}
