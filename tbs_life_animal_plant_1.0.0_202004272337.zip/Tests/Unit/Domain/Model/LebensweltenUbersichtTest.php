<?php
namespace Tbs\TbsLifeAnimalPlant\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class LebensweltenUbersichtTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getName()
        );
    }

    /**
     * @test
     */
    public function setNameForStringSetsName()
    {
        $this->subject->setName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'name',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHeaderImageReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getHeaderImage()
        );
    }

    /**
     * @test
     */
    public function setHeaderImageForFileReferenceSetsHeaderImage()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setHeaderImage($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'headerImage',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTitleGalleryReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTitleGallery()
        );
    }

    /**
     * @test
     */
    public function setTitleGalleryForStringSetsTitleGallery()
    {
        $this->subject->setTitleGallery('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'titleGallery',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getImagesReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getImages()
        );
    }

    /**
     * @test
     */
    public function setImagesForFileReferenceSetsImages()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setImages($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'images',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getDescriptionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getDescription()
        );
    }

    /**
     * @test
     */
    public function setDescriptionForStringSetsDescription()
    {
        $this->subject->setDescription('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'description',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSpaceReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSpace()
        );
    }

    /**
     * @test
     */
    public function setSpaceForStringSetsSpace()
    {
        $this->subject->setSpace('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'space',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSpeciesAnimalReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSpeciesAnimal()
        );
    }

    /**
     * @test
     */
    public function setSpeciesAnimalForStringSetsSpeciesAnimal()
    {
        $this->subject->setSpeciesAnimal('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'speciesAnimal',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getSpeciesPlantReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSpeciesPlant()
        );
    }

    /**
     * @test
     */
    public function setSpeciesPlantForStringSetsSpeciesPlant()
    {
        $this->subject->setSpeciesPlant('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'speciesPlant',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getBusinessTimeReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getBusinessTime()
        );
    }

    /**
     * @test
     */
    public function setBusinessTimeForStringSetsBusinessTime()
    {
        $this->subject->setBusinessTime('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'businessTime',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTeaserDescriptionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTeaserDescription()
        );
    }

    /**
     * @test
     */
    public function setTeaserDescriptionForStringSetsTeaserDescription()
    {
        $this->subject->setTeaserDescription('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'teaserDescription',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getAnimalsReturnsInitialValueForTiereUbersicht()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getAnimals()
        );
    }

    /**
     * @test
     */
    public function setAnimalsForObjectStorageContainingTiereUbersichtSetsAnimals()
    {
        $animal = new \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht();
        $objectStorageHoldingExactlyOneAnimals = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneAnimals->attach($animal);
        $this->subject->setAnimals($objectStorageHoldingExactlyOneAnimals);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneAnimals,
            'animals',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addAnimalToObjectStorageHoldingAnimals()
    {
        $animal = new \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht();
        $animalsObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $animalsObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($animal));
        $this->inject($this->subject, 'animals', $animalsObjectStorageMock);

        $this->subject->addAnimal($animal);
    }

    /**
     * @test
     */
    public function removeAnimalFromObjectStorageHoldingAnimals()
    {
        $animal = new \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht();
        $animalsObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $animalsObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($animal));
        $this->inject($this->subject, 'animals', $animalsObjectStorageMock);

        $this->subject->removeAnimal($animal);
    }

    /**
     * @test
     */
    public function getPlantsReturnsInitialValueForPflanzenarten()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getPlants()
        );
    }

    /**
     * @test
     */
    public function setPlantsForObjectStorageContainingPflanzenartenSetsPlants()
    {
        $plant = new \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten();
        $objectStorageHoldingExactlyOnePlants = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOnePlants->attach($plant);
        $this->subject->setPlants($objectStorageHoldingExactlyOnePlants);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOnePlants,
            'plants',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addPlantToObjectStorageHoldingPlants()
    {
        $plant = new \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten();
        $plantsObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $plantsObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($plant));
        $this->inject($this->subject, 'plants', $plantsObjectStorageMock);

        $this->subject->addPlant($plant);
    }

    /**
     * @test
     */
    public function removePlantFromObjectStorageHoldingPlants()
    {
        $plant = new \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten();
        $plantsObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $plantsObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($plant));
        $this->inject($this->subject, 'plants', $plantsObjectStorageMock);

        $this->subject->removePlant($plant);
    }
}
