<?php
namespace Tbs\TbsLifeAnimalPlant\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class LebensweltenUbersichtControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsLifeAnimalPlant\Controller\LebensweltenUbersichtController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsLifeAnimalPlant\Controller\LebensweltenUbersichtController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllLebensweltenUbersichtsFromRepositoryAndAssignsThemToView()
    {

        $allLebensweltenUbersichts = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $lebensweltenUbersichtRepository = $this->getMockBuilder(\Tbs\TbsLifeAnimalPlant\Domain\Repository\LebensweltenUbersichtRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $lebensweltenUbersichtRepository->expects(self::once())->method('findAll')->will(self::returnValue($allLebensweltenUbersichts));
        $this->inject($this->subject, 'lebensweltenUbersichtRepository', $lebensweltenUbersichtRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('lebensweltenUbersichts', $allLebensweltenUbersichts);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenLebensweltenUbersichtToView()
    {
        $lebensweltenUbersicht = new \Tbs\TbsLifeAnimalPlant\Domain\Model\LebensweltenUbersicht();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('lebensweltenUbersicht', $lebensweltenUbersicht);

        $this->subject->showAction($lebensweltenUbersicht);
    }
}
