<?php
namespace Tbs\TbsLifeAnimalPlant\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class TiereUbersichtControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsLifeAnimalPlant\Controller\TiereUbersichtController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsLifeAnimalPlant\Controller\TiereUbersichtController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllTiereUbersichtsFromRepositoryAndAssignsThemToView()
    {

        $allTiereUbersichts = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $tiereUbersichtRepository = $this->getMockBuilder(\Tbs\TbsLifeAnimalPlant\Domain\Repository\TiereUbersichtRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $tiereUbersichtRepository->expects(self::once())->method('findAll')->will(self::returnValue($allTiereUbersichts));
        $this->inject($this->subject, 'tiereUbersichtRepository', $tiereUbersichtRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('tiereUbersichts', $allTiereUbersichts);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenTiereUbersichtToView()
    {
        $tiereUbersicht = new \Tbs\TbsLifeAnimalPlant\Domain\Model\TiereUbersicht();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('tiereUbersicht', $tiereUbersicht);

        $this->subject->showAction($tiereUbersicht);
    }
}
