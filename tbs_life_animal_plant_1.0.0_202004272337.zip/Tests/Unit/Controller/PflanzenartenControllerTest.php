<?php
namespace Tbs\TbsLifeAnimalPlant\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class PflanzenartenControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsLifeAnimalPlant\Controller\PflanzenartenController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsLifeAnimalPlant\Controller\PflanzenartenController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllPflanzenartensFromRepositoryAndAssignsThemToView()
    {

        $allPflanzenartens = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $pflanzenartenRepository = $this->getMockBuilder(\Tbs\TbsLifeAnimalPlant\Domain\Repository\PflanzenartenRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $pflanzenartenRepository->expects(self::once())->method('findAll')->will(self::returnValue($allPflanzenartens));
        $this->inject($this->subject, 'pflanzenartenRepository', $pflanzenartenRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('pflanzenartens', $allPflanzenartens);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenPflanzenartenToView()
    {
        $pflanzenarten = new \Tbs\TbsLifeAnimalPlant\Domain\Model\Pflanzenarten();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('pflanzenarten', $pflanzenarten);

        $this->subject->showAction($pflanzenarten);
    }
}
