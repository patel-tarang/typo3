<?php
namespace Brettingham\TbsTimePlanning\Controller;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * OpeningTimeController
 */
class OpeningTimeController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * openingTimeRepository
     *
     * @var \Brettingham\TbsTimePlanning\Domain\Repository\OpeningTimeRepository
     * @inject
     */
    protected $openingTimeRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $openingTimes = $this->openingTimeRepository->findAll();
        $this->view->assign('openingTimes', $openingTimes);
    }

    /**
     * action show
     *
     * @param \Brettingham\TbsTimePlanning\Domain\Model\OpeningTime $openingTime
     * @return void
     */
    public function showAction(\Brettingham\TbsTimePlanning\Domain\Model\OpeningTime $openingTime)
    {
        $this->view->assign('openingTime', $openingTime);
    }
}
