<?php
namespace Brettingham\TbsTimePlanning\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class OpeningTimeTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Brettingham\TbsTimePlanning\Domain\Model\OpeningTime
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Brettingham\TbsTimePlanning\Domain\Model\OpeningTime();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getMonthNameReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getMonthName()
        );
    }

    /**
     * @test
     */
    public function setMonthNameForIntSetsMonthName()
    {
        $this->subject->setMonthName(12);

        self::assertAttributeEquals(
            12,
            'monthName',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getMonthClosingReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getMonthClosing()
        );
    }

    /**
     * @test
     */
    public function setMonthClosingForDateTimeSetsMonthClosing()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setMonthClosing($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'monthClosing',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getMonthEntryInfoReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getMonthEntryInfo()
        );
    }

    /**
     * @test
     */
    public function setMonthEntryInfoForStringSetsMonthEntryInfo()
    {
        $this->subject->setMonthEntryInfo('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'monthEntryInfo',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getEntryMainReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getEntryMain()
        );
    }

    /**
     * @test
     */
    public function setEntryMainForObjectStorageContainingMonthEntryTimeSetsEntryMain()
    {
        $entryMain = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneEntryMain = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneEntryMain->attach($entryMain);
        $this->subject->setEntryMain($objectStorageHoldingExactlyOneEntryMain);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneEntryMain,
            'entryMain',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addEntryMainToObjectStorageHoldingEntryMain()
    {
        $entryMain = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $entryMainObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $entryMainObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($entryMain));
        $this->inject($this->subject, 'entryMain', $entryMainObjectStorageMock);

        $this->subject->addEntryMain($entryMain);
    }

    /**
     * @test
     */
    public function removeEntryMainFromObjectStorageHoldingEntryMain()
    {
        $entryMain = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $entryMainObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $entryMainObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($entryMain));
        $this->inject($this->subject, 'entryMain', $entryMainObjectStorageMock);

        $this->subject->removeEntryMain($entryMain);
    }

    /**
     * @test
     */
    public function getEntryRoseReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getEntryRose()
        );
    }

    /**
     * @test
     */
    public function setEntryRoseForObjectStorageContainingMonthEntryTimeSetsEntryRose()
    {
        $entryRose = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneEntryRose = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneEntryRose->attach($entryRose);
        $this->subject->setEntryRose($objectStorageHoldingExactlyOneEntryRose);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneEntryRose,
            'entryRose',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addEntryRoseToObjectStorageHoldingEntryRose()
    {
        $entryRose = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $entryRoseObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $entryRoseObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($entryRose));
        $this->inject($this->subject, 'entryRose', $entryRoseObjectStorageMock);

        $this->subject->addEntryRose($entryRose);
    }

    /**
     * @test
     */
    public function removeEntryRoseFromObjectStorageHoldingEntryRose()
    {
        $entryRose = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $entryRoseObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $entryRoseObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($entryRose));
        $this->inject($this->subject, 'entryRose', $entryRoseObjectStorageMock);

        $this->subject->removeEntryRose($entryRose);
    }

    /**
     * @test
     */
    public function getEntryPragReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getEntryPrag()
        );
    }

    /**
     * @test
     */
    public function setEntryPragForObjectStorageContainingMonthEntryTimeSetsEntryPrag()
    {
        $entryPrag = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneEntryPrag = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneEntryPrag->attach($entryPrag);
        $this->subject->setEntryPrag($objectStorageHoldingExactlyOneEntryPrag);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneEntryPrag,
            'entryPrag',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addEntryPragToObjectStorageHoldingEntryPrag()
    {
        $entryPrag = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $entryPragObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $entryPragObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($entryPrag));
        $this->inject($this->subject, 'entryPrag', $entryPragObjectStorageMock);

        $this->subject->addEntryPrag($entryPrag);
    }

    /**
     * @test
     */
    public function removeEntryPragFromObjectStorageHoldingEntryPrag()
    {
        $entryPrag = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $entryPragObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $entryPragObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($entryPrag));
        $this->inject($this->subject, 'entryPrag', $entryPragObjectStorageMock);

        $this->subject->removeEntryPrag($entryPrag);
    }

    /**
     * @test
     */
    public function getHouseAnimalReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getHouseAnimal()
        );
    }

    /**
     * @test
     */
    public function setHouseAnimalForObjectStorageContainingMonthEntryTimeSetsHouseAnimal()
    {
        $houseAnimal = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneHouseAnimal = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneHouseAnimal->attach($houseAnimal);
        $this->subject->setHouseAnimal($objectStorageHoldingExactlyOneHouseAnimal);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneHouseAnimal,
            'houseAnimal',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addHouseAnimalToObjectStorageHoldingHouseAnimal()
    {
        $houseAnimal = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $houseAnimalObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $houseAnimalObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($houseAnimal));
        $this->inject($this->subject, 'houseAnimal', $houseAnimalObjectStorageMock);

        $this->subject->addHouseAnimal($houseAnimal);
    }

    /**
     * @test
     */
    public function removeHouseAnimalFromObjectStorageHoldingHouseAnimal()
    {
        $houseAnimal = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $houseAnimalObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $houseAnimalObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($houseAnimal));
        $this->inject($this->subject, 'houseAnimal', $houseAnimalObjectStorageMock);

        $this->subject->removeHouseAnimal($houseAnimal);
    }

    /**
     * @test
     */
    public function getHousePlantReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getHousePlant()
        );
    }

    /**
     * @test
     */
    public function setHousePlantForObjectStorageContainingMonthEntryTimeSetsHousePlant()
    {
        $housePlant = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneHousePlant = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneHousePlant->attach($housePlant);
        $this->subject->setHousePlant($objectStorageHoldingExactlyOneHousePlant);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneHousePlant,
            'housePlant',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addHousePlantToObjectStorageHoldingHousePlant()
    {
        $housePlant = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $housePlantObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $housePlantObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($housePlant));
        $this->inject($this->subject, 'housePlant', $housePlantObjectStorageMock);

        $this->subject->addHousePlant($housePlant);
    }

    /**
     * @test
     */
    public function removeHousePlantFromObjectStorageHoldingHousePlant()
    {
        $housePlant = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $housePlantObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $housePlantObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($housePlant));
        $this->inject($this->subject, 'housePlant', $housePlantObjectStorageMock);

        $this->subject->removeHousePlant($housePlant);
    }

    /**
     * @test
     */
    public function getHouseHalReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getHouseHal()
        );
    }

    /**
     * @test
     */
    public function setHouseHalForObjectStorageContainingMonthEntryTimeSetsHouseHal()
    {
        $houseHal = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneHouseHal = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneHouseHal->attach($houseHal);
        $this->subject->setHouseHal($objectStorageHoldingExactlyOneHouseHal);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneHouseHal,
            'houseHal',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addHouseHalToObjectStorageHoldingHouseHal()
    {
        $houseHal = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $houseHalObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $houseHalObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($houseHal));
        $this->inject($this->subject, 'houseHal', $houseHalObjectStorageMock);

        $this->subject->addHouseHal($houseHal);
    }

    /**
     * @test
     */
    public function removeHouseHalFromObjectStorageHoldingHouseHal()
    {
        $houseHal = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $houseHalObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $houseHalObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($houseHal));
        $this->inject($this->subject, 'houseHal', $houseHalObjectStorageMock);

        $this->subject->removeHouseHal($houseHal);
    }
}
