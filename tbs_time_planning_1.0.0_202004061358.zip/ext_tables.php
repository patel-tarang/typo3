<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsTimePlanning',
            'Tbstimeplanning',
            'Opening Time'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('tbs_time_planning', 'Configuration/TypoScript', 'TBS Time Planning');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_tbstimeplanning_domain_model_openingtime', 'EXT:tbs_time_planning/Resources/Private/Language/locallang_csh_tx_tbstimeplanning_domain_model_openingtime.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbstimeplanning_domain_model_openingtime');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_tbstimeplanning_domain_model_monthentrytime', 'EXT:tbs_time_planning/Resources/Private/Language/locallang_csh_tx_tbstimeplanning_domain_model_monthentrytime.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbstimeplanning_domain_model_monthentrytime');

    }
);
