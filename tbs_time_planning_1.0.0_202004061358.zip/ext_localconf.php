<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsTimePlanning',
            'Tbstimeplanning',
            [
                'OpeningTime' => 'list, show',
                'MonthEntryTime' => 'list'
            ],
            // non-cacheable actions
            [
                'OpeningTime' => '',
                'MonthEntryTime' => ''
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    tbstimeplanning {
                        iconIdentifier = tbs_time_planning-plugin-tbstimeplanning
                        title = LLL:EXT:tbs_time_planning/Resources/Private/Language/locallang_db.xlf:tx_tbs_time_planning_tbstimeplanning.name
                        description = LLL:EXT:tbs_time_planning/Resources/Private/Language/locallang_db.xlf:tx_tbs_time_planning_tbstimeplanning.description
                        tt_content_defValues {
                            CType = list
                            list_type = tbstimeplanning_tbstimeplanning
                        }
                    }
                }
                show = *
            }
       }'
    );
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
		
			$iconRegistry->registerIcon(
				'tbs_time_planning-plugin-tbstimeplanning',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:tbs_time_planning/Resources/Public/Icons/user_plugin_tbstimeplanning.svg']
			);
		
    }
);
