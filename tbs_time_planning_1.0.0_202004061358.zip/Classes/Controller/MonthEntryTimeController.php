<?php
namespace Tbs\TbsTimePlanning\Controller;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * MonthEntryTimeController
 */
class MonthEntryTimeController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $monthEntryTimes = $this->monthEntryTimeRepository->findAll();
        $this->view->assign('monthEntryTimes', $monthEntryTimes);
    }
}
