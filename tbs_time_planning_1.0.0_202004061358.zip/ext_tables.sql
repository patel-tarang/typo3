#
# Table structure for table 'tx_tbstimeplanning_domain_model_openingtime'
#
CREATE TABLE tx_tbstimeplanning_domain_model_openingtime (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	month_name int(11) DEFAULT '0' NOT NULL,
	month_closing int(11) DEFAULT '0' NOT NULL,
	month_entry_info text,
	entry_main int(11) unsigned DEFAULT '0' NOT NULL,
	entry_rose int(11) unsigned DEFAULT '0' NOT NULL,
	entry_prag int(11) unsigned DEFAULT '0' NOT NULL,
	house_animal int(11) unsigned DEFAULT '0' NOT NULL,
	house_plant int(11) unsigned DEFAULT '0' NOT NULL,
	house_hal int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);

#
# Table structure for table 'tx_tbstimeplanning_domain_model_monthentrytime'
#
CREATE TABLE tx_tbstimeplanning_domain_model_monthentrytime (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	openingtime int(11) unsigned DEFAULT '0' NOT NULL,
	openingtime1 int(11) unsigned DEFAULT '0' NOT NULL,
	openingtime2 int(11) unsigned DEFAULT '0' NOT NULL,
	openingtime3 int(11) unsigned DEFAULT '0' NOT NULL,
	openingtime4 int(11) unsigned DEFAULT '0' NOT NULL,
	openingtime5 int(11) unsigned DEFAULT '0' NOT NULL,

	info_text varchar(255) DEFAULT '' NOT NULL,
	start_day int(11) DEFAULT '0' NOT NULL,
	end_day int(11) DEFAULT '0' NOT NULL,
	open_time_start int(11) DEFAULT '0' NOT NULL,
	open_time_end int(11) DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);

#
# Table structure for table 'tx_tbstimeplanning_domain_model_monthentrytime'
#
CREATE TABLE tx_tbstimeplanning_domain_model_monthentrytime (

	openingtime int(11) unsigned DEFAULT '0' NOT NULL,

	openingtime1 int(11) unsigned DEFAULT '0' NOT NULL,

	openingtime2 int(11) unsigned DEFAULT '0' NOT NULL,

	openingtime3 int(11) unsigned DEFAULT '0' NOT NULL,

	openingtime4 int(11) unsigned DEFAULT '0' NOT NULL,

	openingtime5 int(11) unsigned DEFAULT '0' NOT NULL,

);
