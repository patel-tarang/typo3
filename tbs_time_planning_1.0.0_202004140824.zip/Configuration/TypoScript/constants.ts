
plugin.tx_tbstimeplanning_tbstimeplanning {
    view {
        # cat=plugin.tx_tbstimeplanning_tbstimeplanning/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:tbs_time_planning/Resources/Private/Templates/
        # cat=plugin.tx_tbstimeplanning_tbstimeplanning/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:tbs_time_planning/Resources/Private/Partials/
        # cat=plugin.tx_tbstimeplanning_tbstimeplanning/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:tbs_time_planning/Resources/Private/Layouts/
    }
    persistence {
        # cat=plugin.tx_tbstimeplanning_tbstimeplanning//a; type=string; label=Default storage PID
        storagePid =
    }
}

plugin.tx_tbstimeplanning_tbsfeedingtime {
    view {
        # cat=plugin.tx_tbstimeplanning_tbsfeedingtime/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:tbs_time_planning/Resources/Private/Templates/
        # cat=plugin.tx_tbstimeplanning_tbsfeedingtime/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:tbs_time_planning/Resources/Private/Partials/
        # cat=plugin.tx_tbstimeplanning_tbsfeedingtime/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:tbs_time_planning/Resources/Private/Layouts/
    }
    persistence {
        # cat=plugin.tx_tbstimeplanning_tbsfeedingtime//a; type=string; label=Default storage PID
        storagePid =
    }
}
