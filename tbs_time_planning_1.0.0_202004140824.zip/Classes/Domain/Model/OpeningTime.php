<?php
namespace Tbs\TbsTimePlanning\Domain\Model;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * OpeningTime
 */
class OpeningTime extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * monthName
     *
     * @var int
     */
    protected $monthName = 0;

    /**
     * monthClosing
     *
     * @var \DateTime
     */
    protected $monthClosing = null;

    /**
     * monthEntryInfo
     *
     * @var string
     */
    protected $monthEntryInfo = '';

    /**
     * entryMain
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $entryMain = null;

    /**
     * entryRose
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $entryRose = null;

    /**
     * entryPrag
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $entryPrag = null;

    /**
     * houseAnimal
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $houseAnimal = null;

    /**
     * housePlant
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $housePlant = null;

    /**
     * houseHal
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $houseHal = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->entryMain = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->entryRose = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->entryPrag = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->houseAnimal = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->housePlant = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->houseHal = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the monthName
     *
     * @return int $monthName
     */
    public function getMonthName()
    {
        return $this->monthName;
    }

    /**
     * Sets the monthName
     *
     * @param int $monthName
     * @return void
     */
    public function setMonthName($monthName)
    {
        $this->monthName = $monthName;
    }

    /**
     * Returns the monthClosing
     *
     * @return \DateTime $monthClosing
     */
    public function getMonthClosing()
    {
        return $this->monthClosing;
    }

    /**
     * Sets the monthClosing
     *
     * @param \DateTime $monthClosing
     * @return void
     */
    public function setMonthClosing(\DateTime $monthClosing)
    {
        $this->monthClosing = $monthClosing;
    }

    /**
     * Returns the monthEntryInfo
     *
     * @return string $monthEntryInfo
     */
    public function getMonthEntryInfo()
    {
        return $this->monthEntryInfo;
    }

    /**
     * Sets the monthEntryInfo
     *
     * @param string $monthEntryInfo
     * @return void
     */
    public function setMonthEntryInfo($monthEntryInfo)
    {
        $this->monthEntryInfo = $monthEntryInfo;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryMain
     * @return void
     */
    public function addEntryMain(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryMain)
    {
        $this->entryMain->attach($entryMain);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryMainToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeEntryMain(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryMainToRemove)
    {
        $this->entryMain->detach($entryMainToRemove);
    }

    /**
     * Returns the entryMain
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> entryMain
     */
    public function getEntryMain()
    {
        return $this->entryMain;
    }

    /**
     * Sets the entryMain
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> $entryMain
     * @return void
     */
    public function setEntryMain(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $entryMain)
    {
        $this->entryMain = $entryMain;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryRose
     * @return void
     */
    public function addEntryRose(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryRose)
    {
        $this->entryRose->attach($entryRose);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryRoseToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeEntryRose(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryRoseToRemove)
    {
        $this->entryRose->detach($entryRoseToRemove);
    }

    /**
     * Returns the entryRose
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> entryRose
     */
    public function getEntryRose()
    {
        return $this->entryRose;
    }

    /**
     * Sets the entryRose
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> $entryRose
     * @return void
     */
    public function setEntryRose(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $entryRose)
    {
        $this->entryRose = $entryRose;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryPrag
     * @return void
     */
    public function addEntryPrag(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryPrag)
    {
        $this->entryPrag->attach($entryPrag);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryPragToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeEntryPrag(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $entryPragToRemove)
    {
        $this->entryPrag->detach($entryPragToRemove);
    }

    /**
     * Returns the entryPrag
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> entryPrag
     */
    public function getEntryPrag()
    {
        return $this->entryPrag;
    }

    /**
     * Sets the entryPrag
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> $entryPrag
     * @return void
     */
    public function setEntryPrag(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $entryPrag)
    {
        $this->entryPrag = $entryPrag;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseAnimal
     * @return void
     */
    public function addHouseAnimal(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseAnimal)
    {
        $this->houseAnimal->attach($houseAnimal);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseAnimalToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeHouseAnimal(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseAnimalToRemove)
    {
        $this->houseAnimal->detach($houseAnimalToRemove);
    }

    /**
     * Returns the houseAnimal
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> houseAnimal
     */
    public function getHouseAnimal()
    {
        return $this->houseAnimal;
    }

    /**
     * Sets the houseAnimal
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> $houseAnimal
     * @return void
     */
    public function setHouseAnimal(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $houseAnimal)
    {
        $this->houseAnimal = $houseAnimal;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $housePlant
     * @return void
     */
    public function addHousePlant(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $housePlant)
    {
        $this->housePlant->attach($housePlant);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $housePlantToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeHousePlant(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $housePlantToRemove)
    {
        $this->housePlant->detach($housePlantToRemove);
    }

    /**
     * Returns the housePlant
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> housePlant
     */
    public function getHousePlant()
    {
        return $this->housePlant;
    }

    /**
     * Sets the housePlant
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> $housePlant
     * @return void
     */
    public function setHousePlant(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $housePlant)
    {
        $this->housePlant = $housePlant;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseHal
     * @return void
     */
    public function addHouseHal(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseHal)
    {
        $this->houseHal->attach($houseHal);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseHalToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeHouseHal(\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime $houseHalToRemove)
    {
        $this->houseHal->detach($houseHalToRemove);
    }

    /**
     * Returns the houseHal
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> houseHal
     */
    public function getHouseHal()
    {
        return $this->houseHal;
    }

    /**
     * Sets the houseHal
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime> $houseHal
     * @return void
     */
    public function setHouseHal(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $houseHal)
    {
        $this->houseHal = $houseHal;
    }
}
