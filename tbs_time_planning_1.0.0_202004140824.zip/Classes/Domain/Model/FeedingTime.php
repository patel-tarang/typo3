<?php
namespace Tbs\TbsTimePlanning\Domain\Model;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * FeedingTime
 */
class FeedingTime extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * name
     *
     * @var string
     */
    protected $name = '';

    /**
     * icon
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $icon = null;

    /**
     * isCommented
     *
     * @var bool
     */
    protected $isCommented = false;

    /**
     * feedingTime
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime>
     * @cascade remove
     */
    protected $feedingTime = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->feedingTime = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the name
     *
     * @return string $name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Sets the name
     *
     * @param string $name
     * @return void
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * Returns the icon
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $icon
     */
    public function getIcon()
    {
        return $this->icon;
    }

    /**
     * Sets the icon
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $icon
     * @return void
     */
    public function setIcon(\TYPO3\CMS\Extbase\Domain\Model\FileReference $icon)
    {
        $this->icon = $icon;
    }

    /**
     * Returns the isCommented
     *
     * @return bool $isCommented
     */
    public function getIsCommented()
    {
        return $this->isCommented;
    }

    /**
     * Sets the isCommented
     *
     * @param bool $isCommented
     * @return void
     */
    public function setIsCommented($isCommented)
    {
        $this->isCommented = $isCommented;
    }

    /**
     * Returns the boolean state of isCommented
     *
     * @return bool
     */
    public function isIsCommented()
    {
        return $this->isCommented;
    }

    /**
     * Adds a AnimalFeedingTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime $feedingTime
     * @return void
     */
    public function addFeedingTime(\Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime $feedingTime)
    {
        $this->feedingTime->attach($feedingTime);
    }

    /**
     * Removes a AnimalFeedingTime
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime $feedingTimeToRemove The AnimalFeedingTime to be removed
     * @return void
     */
    public function removeFeedingTime(\Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime $feedingTimeToRemove)
    {
        $this->feedingTime->detach($feedingTimeToRemove);
    }

    /**
     * Returns the feedingTime
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime> $feedingTime
     */
    public function getFeedingTime()
    {
        return $this->feedingTime;
    }

    /**
     * Sets the feedingTime
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime> $feedingTime
     * @return void
     */
    public function setFeedingTime(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $feedingTime)
    {
        $this->feedingTime = $feedingTime;
    }
}
