<?php
namespace Tbs\TbsTimePlanning\Domain\Model;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * MonthEntryTime
 */
class MonthEntryTime extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * infoText
     *
     * @var string
     */
    protected $infoText = '';

    /**
     * startDay
     *
     * @var \DateTime
     */
    protected $startDay = null;

    /**
     * endDay
     *
     * @var \DateTime
     */
    protected $endDay = null;

    /**
     * openTimeStart
     *
     * @var int
     */
    protected $openTimeStart = 0;

    /**
     * openTimeEnd
     *
     * @var int
     */
    protected $openTimeEnd = 0;

    /**
     * Returns the infoText
     *
     * @return string $infoText
     */
    public function getInfoText()
    {
        return $this->infoText;
    }

    /**
     * Sets the infoText
     *
     * @param string $infoText
     * @return void
     */
    public function setInfoText($infoText)
    {
        $this->infoText = $infoText;
    }

    /**
     * Returns the startDay
     *
     * @return \DateTime $startDay
     */
    public function getStartDay()
    {
        return $this->startDay;
    }

    /**
     * Sets the startDay
     *
     * @param \DateTime $startDay
     * @return void
     */
    public function setStartDay(\DateTime $startDay)
    {
        $this->startDay = $startDay;
    }

    /**
     * Returns the endDay
     *
     * @return \DateTime $endDay
     */
    public function getEndDay()
    {
        return $this->endDay;
    }

    /**
     * Sets the endDay
     *
     * @param \DateTime $endDay
     * @return void
     */
    public function setEndDay(\DateTime $endDay)
    {
        $this->endDay = $endDay;
    }

    /**
     * Returns the openTimeStart
     *
     * @return int $openTimeStart
     */
    public function getOpenTimeStart()
    {
        return $this->openTimeStart;
    }

    /**
     * Sets the openTimeStart
     *
     * @param int $openTimeStart
     * @return void
     */
    public function setOpenTimeStart(int $openTimeStart)
    {
        $this->openTimeStart = $openTimeStart;
    }

    /**
     * Returns the openTimeEnd
     *
     * @return int $openTimeEnd
     */
    public function getOpenTimeEnd()
    {
        return $this->openTimeEnd;
    }

    /**
     * Sets the openTimeEnd
     *
     * @param int $openTimeEnd
     * @return void
     */
    public function setOpenTimeEnd(int $openTimeEnd)
    {
        $this->openTimeEnd = $openTimeEnd;
    }
}
