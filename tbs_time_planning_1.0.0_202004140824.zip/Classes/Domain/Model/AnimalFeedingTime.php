<?php
namespace Tbs\TbsTimePlanning\Domain\Model;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * AnimalFeedingTime
 */
class AnimalFeedingTime extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * day
     *
     * @var int
     */
    protected $day = 0;

    /**
     * startMonth
     *
     * @var int
     */
    protected $startMonth = 0;

    /**
     * endMonth
     *
     * @var int
     */
    protected $endMonth = 0;

    /**
     * wholeYear
     *
     * @var bool
     */
    protected $wholeYear = false;

    /**
     * feedTimeStart
     *
     * @var int
     */
    protected $feedTimeStart = 0;

    /**
     * feddTimeEnd
     *
     * @var int
     */
    protected $feddTimeEnd = 0;

    /**
     * Returns the day
     *
     * @return int $day
     */
    public function getDay()
    {
        return $this->day;
    }

    /**
     * Sets the day
     *
     * @param int $day
     * @return void
     */
    public function setDay($day)
    {
        $this->day = $day;
    }

    /**
     * Returns the startMonth
     *
     * @return int $startMonth
     */
    public function getStartMonth()
    {
        return $this->startMonth;
    }

    /**
     * Sets the startMonth
     *
     * @param int $startMonth
     * @return void
     */
    public function setStartMonth($startMonth)
    {
        $this->startMonth = $startMonth;
    }

    /**
     * Returns the endMonth
     *
     * @return int $endMonth
     */
    public function getEndMonth()
    {
        return $this->endMonth;
    }

    /**
     * Sets the endMonth
     *
     * @param int $endMonth
     * @return void
     */
    public function setEndMonth($endMonth)
    {
        $this->endMonth = $endMonth;
    }

    /**
     * Returns the wholeYear
     *
     * @return bool $wholeYear
     */
    public function getWholeYear()
    {
        return $this->wholeYear;
    }

    /**
     * Sets the wholeYear
     *
     * @param bool $wholeYear
     * @return void
     */
    public function setWholeYear($wholeYear)
    {
        $this->wholeYear = $wholeYear;
    }

    /**
     * Returns the boolean state of wholeYear
     *
     * @return bool
     */
    public function isWholeYear()
    {
        return $this->wholeYear;
    }

    /**
     * Returns the feedTimeStart
     *
     * @return int $feedTimeStart
     */
    public function getFeedTimeStart()
    {
        return $this->feedTimeStart;
    }

    /**
     * Sets the feedTimeStart
     *
     * @param int $feedTimeStart
     * @return void
     */
    public function setFeedTimeStart(int $feedTimeStart)
    {
        $this->feedTimeStart = $feedTimeStart;
    }

    /**
     * Returns the feddTimeEnd
     *
     * @return int $feddTimeEnd
     */
    public function getFeddTimeEnd()
    {
        return $this->feddTimeEnd;
    }

    /**
     * Sets the feddTimeEnd
     *
     * @param int $feddTimeEnd
     * @return void
     */
    public function setFeddTimeEnd(int $feddTimeEnd)
    {
        $this->feddTimeEnd = $feddTimeEnd;
    }
}
