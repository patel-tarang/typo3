<?php
namespace Tbs\TbsTimePlanning\Controller;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * AnimalFeedingTimeController
 */
class AnimalFeedingTimeController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $animalFeedingTimes = $this->animalFeedingTimeRepository->findAll();
        $this->view->assign('animalFeedingTimes', $animalFeedingTimes);
    }
}
