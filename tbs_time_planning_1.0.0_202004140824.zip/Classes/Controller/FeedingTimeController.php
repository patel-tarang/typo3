<?php
namespace Tbs\TbsTimePlanning\Controller;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * FeedingTimeController
 */
class FeedingTimeController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * feedingTimeRepository
     *
     * @var \Tbs\TbsTimePlanning\Domain\Repository\FeedingTimeRepository
     * @inject
     */
    protected $feedingTimeRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $feedingTimes = $this->feedingTimeRepository->findAll();
        $this->view->assign('feedingTimes', $feedingTimes);
    }

    /**
     * action show
     *
     * @param \Tbs\TbsTimePlanning\Domain\Model\FeedingTime $feedingTime
     * @return void
     */
    public function showAction(\Tbs\TbsTimePlanning\Domain\Model\FeedingTime $feedingTime)
    {
        $this->view->assign('feedingTime', $feedingTime);
    }
}
