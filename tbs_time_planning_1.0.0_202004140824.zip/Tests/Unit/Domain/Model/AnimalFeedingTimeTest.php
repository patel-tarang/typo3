<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class AnimalFeedingTimeTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getDayReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getDay()
        );
    }

    /**
     * @test
     */
    public function setDayForIntSetsDay()
    {
        $this->subject->setDay(12);

        self::assertAttributeEquals(
            12,
            'day',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getStartMonthReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getStartMonth()
        );
    }

    /**
     * @test
     */
    public function setStartMonthForIntSetsStartMonth()
    {
        $this->subject->setStartMonth(12);

        self::assertAttributeEquals(
            12,
            'startMonth',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getEndMonthReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getEndMonth()
        );
    }

    /**
     * @test
     */
    public function setEndMonthForIntSetsEndMonth()
    {
        $this->subject->setEndMonth(12);

        self::assertAttributeEquals(
            12,
            'endMonth',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getWholeYearReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getWholeYear()
        );
    }

    /**
     * @test
     */
    public function setWholeYearForBoolSetsWholeYear()
    {
        $this->subject->setWholeYear(true);

        self::assertAttributeEquals(
            true,
            'wholeYear',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getFeedTimeStartReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getFeedTimeStart()
        );
    }

    /**
     * @test
     */
    public function setFeedTimeStartForIntSetsFeedTimeStart()
    {
        $this->subject->setFeedTimeStart(12);

        self::assertAttributeEquals(
            12,
            'feedTimeStart',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getFeddTimeEndReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getFeddTimeEnd()
        );
    }

    /**
     * @test
     */
    public function setFeddTimeEndForIntSetsFeddTimeEnd()
    {
        $this->subject->setFeddTimeEnd(12);

        self::assertAttributeEquals(
            12,
            'feddTimeEnd',
            $this->subject
        );
    }
}
