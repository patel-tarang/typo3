<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class FeedingTimeTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Domain\Model\FeedingTime
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Tbs\TbsTimePlanning\Domain\Model\FeedingTime();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getName()
        );
    }

    /**
     * @test
     */
    public function setNameForStringSetsName()
    {
        $this->subject->setName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'name',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getIconReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getIcon()
        );
    }

    /**
     * @test
     */
    public function setIconForFileReferenceSetsIcon()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setIcon($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'icon',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getIsCommentedReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getIsCommented()
        );
    }

    /**
     * @test
     */
    public function setIsCommentedForBoolSetsIsCommented()
    {
        $this->subject->setIsCommented(true);

        self::assertAttributeEquals(
            true,
            'isCommented',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getFeedingTimeReturnsInitialValueForAnimalFeedingTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getFeedingTime()
        );
    }

    /**
     * @test
     */
    public function setFeedingTimeForObjectStorageContainingAnimalFeedingTimeSetsFeedingTime()
    {
        $feedingTime = new \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime();
        $objectStorageHoldingExactlyOneFeedingTime = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneFeedingTime->attach($feedingTime);
        $this->subject->setFeedingTime($objectStorageHoldingExactlyOneFeedingTime);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneFeedingTime,
            'feedingTime',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addFeedingTimeToObjectStorageHoldingFeedingTime()
    {
        $feedingTime = new \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime();
        $feedingTimeObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $feedingTimeObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($feedingTime));
        $this->inject($this->subject, 'feedingTime', $feedingTimeObjectStorageMock);

        $this->subject->addFeedingTime($feedingTime);
    }

    /**
     * @test
     */
    public function removeFeedingTimeFromObjectStorageHoldingFeedingTime()
    {
        $feedingTime = new \Tbs\TbsTimePlanning\Domain\Model\AnimalFeedingTime();
        $feedingTimeObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $feedingTimeObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($feedingTime));
        $this->inject($this->subject, 'feedingTime', $feedingTimeObjectStorageMock);

        $this->subject->removeFeedingTime($feedingTime);
    }
}
