<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class FeedingTimeControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Controller\FeedingTimeController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsTimePlanning\Controller\FeedingTimeController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllFeedingTimesFromRepositoryAndAssignsThemToView()
    {

        $allFeedingTimes = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $feedingTimeRepository = $this->getMockBuilder(\Tbs\TbsTimePlanning\Domain\Repository\FeedingTimeRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $feedingTimeRepository->expects(self::once())->method('findAll')->will(self::returnValue($allFeedingTimes));
        $this->inject($this->subject, 'feedingTimeRepository', $feedingTimeRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('feedingTimes', $allFeedingTimes);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenFeedingTimeToView()
    {
        $feedingTime = new \Tbs\TbsTimePlanning\Domain\Model\FeedingTime();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('feedingTime', $feedingTime);

        $this->subject->showAction($feedingTime);
    }
}
