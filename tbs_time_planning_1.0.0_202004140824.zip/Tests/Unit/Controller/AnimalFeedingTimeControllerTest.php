<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class AnimalFeedingTimeControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Controller\AnimalFeedingTimeController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsTimePlanning\Controller\AnimalFeedingTimeController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllAnimalFeedingTimesFromRepositoryAndAssignsThemToView()
    {

        $allAnimalFeedingTimes = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $animalFeedingTimeRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $animalFeedingTimeRepository->expects(self::once())->method('findAll')->will(self::returnValue($allAnimalFeedingTimes));
        $this->inject($this->subject, 'animalFeedingTimeRepository', $animalFeedingTimeRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('animalFeedingTimes', $allAnimalFeedingTimes);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }
}
