<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class MonthEntryTimeControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Controller\MonthEntryTimeController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsTimePlanning\Controller\MonthEntryTimeController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllMonthEntryTimesFromRepositoryAndAssignsThemToView()
    {

        $allMonthEntryTimes = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $monthEntryTimeRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $monthEntryTimeRepository->expects(self::once())->method('findAll')->will(self::returnValue($allMonthEntryTimes));
        $this->inject($this->subject, 'monthEntryTimeRepository', $monthEntryTimeRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('monthEntryTimes', $allMonthEntryTimes);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }
}
