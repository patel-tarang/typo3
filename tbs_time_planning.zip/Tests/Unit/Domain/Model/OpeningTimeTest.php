<?php
namespace Brettingham\TbsTimePlanning\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class OpeningTimeTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Brettingham\TbsTimePlanning\Domain\Model\OpeningTime
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Brettingham\TbsTimePlanning\Domain\Model\OpeningTime();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getMonthNameReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getMonthName()
        );
    }

    /**
     * @test
     */
    public function setMonthNameForIntSetsMonthName()
    {
        $this->subject->setMonthName(12);

        self::assertAttributeEquals(
            12,
            'monthName',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getEntryMainReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getEntryMain()
        );
    }

    /**
     * @test
     */
    public function setEntryMainForDateTimeSetsEntryMain()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setEntryMain($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'entryMain',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getEntryRoseReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getEntryRose()
        );
    }

    /**
     * @test
     */
    public function setEntryRoseForDateTimeSetsEntryRose()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setEntryRose($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'entryRose',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getEntryPragReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getEntryPrag()
        );
    }

    /**
     * @test
     */
    public function setEntryPragForDateTimeSetsEntryPrag()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setEntryPrag($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'entryPrag',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHouseAnimalReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getHouseAnimal()
        );
    }

    /**
     * @test
     */
    public function setHouseAnimalForDateTimeSetsHouseAnimal()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setHouseAnimal($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'houseAnimal',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHousePlantReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getHousePlant()
        );
    }

    /**
     * @test
     */
    public function setHousePlantForDateTimeSetsHousePlant()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setHousePlant($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'housePlant',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getHouseHalReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getHouseHal()
        );
    }

    /**
     * @test
     */
    public function setHouseHalForDateTimeSetsHouseHal()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setHouseHal($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'houseHal',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getMonthClosingReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getMonthClosing()
        );
    }

    /**
     * @test
     */
    public function setMonthClosingForDateTimeSetsMonthClosing()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setMonthClosing($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'monthClosing',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getMonthEntryInfoReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getMonthEntryInfo()
        );
    }

    /**
     * @test
     */
    public function setMonthEntryInfoForStringSetsMonthEntryInfo()
    {
        $this->subject->setMonthEntryInfo('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'monthEntryInfo',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getMonthEntryTimeReturnsInitialValueForMonthEntryTime()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getMonthEntryTime()
        );
    }

    /**
     * @test
     */
    public function setMonthEntryTimeForObjectStorageContainingMonthEntryTimeSetsMonthEntryTime()
    {
        $monthEntryTime = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $objectStorageHoldingExactlyOneMonthEntryTime = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneMonthEntryTime->attach($monthEntryTime);
        $this->subject->setMonthEntryTime($objectStorageHoldingExactlyOneMonthEntryTime);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneMonthEntryTime,
            'monthEntryTime',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function addMonthEntryTimeToObjectStorageHoldingMonthEntryTime()
    {
        $monthEntryTime = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $monthEntryTimeObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $monthEntryTimeObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($monthEntryTime));
        $this->inject($this->subject, 'monthEntryTime', $monthEntryTimeObjectStorageMock);

        $this->subject->addMonthEntryTime($monthEntryTime);
    }

    /**
     * @test
     */
    public function removeMonthEntryTimeFromObjectStorageHoldingMonthEntryTime()
    {
        $monthEntryTime = new \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime();
        $monthEntryTimeObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $monthEntryTimeObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($monthEntryTime));
        $this->inject($this->subject, 'monthEntryTime', $monthEntryTimeObjectStorageMock);

        $this->subject->removeMonthEntryTime($monthEntryTime);
    }
}
