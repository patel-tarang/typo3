<?php
namespace Brettingham\TbsTimePlanning\Domain\Model;

/***
 *
 * This file is part of the "TBS Time Planning" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, The Brettingham
 *
 ***/

/**
 * OpeningTime
 */
class OpeningTime extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * monthName
     *
     * @var int
     */
    protected $monthName = 0;

    /**
     * entryMain
     *
     * @var \DateTime
     */
    protected $entryMain = null;

    /**
     * entryRose
     *
     * @var \DateTime
     */
    protected $entryRose = null;

    /**
     * entryPrag
     *
     * @var \DateTime
     */
    protected $entryPrag = null;

    /**
     * houseAnimal
     *
     * @var \DateTime
     */
    protected $houseAnimal = null;

    /**
     * housePlant
     *
     * @var \DateTime
     */
    protected $housePlant = null;

    /**
     * houseHal
     *
     * @var \DateTime
     */
    protected $houseHal = null;

    /**
     * monthClosing
     *
     * @var \DateTime
     */
    protected $monthClosing = null;

    /**
     * monthEntryInfo
     *
     * @var string
     */
    protected $monthEntryInfo = '';

    /**
     * monthEntryTime
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime>
     * @cascade remove
     */
    protected $monthEntryTime = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->monthEntryTime = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the monthName
     *
     * @return int $monthName
     */
    public function getMonthName()
    {
        return $this->monthName;
    }

    /**
     * Sets the monthName
     *
     * @param int $monthName
     * @return void
     */
    public function setMonthName($monthName)
    {
        $this->monthName = $monthName;
    }

    /**
     * Returns the entryMain
     *
     * @return \DateTime $entryMain
     */
    public function getEntryMain()
    {
        return $this->entryMain;
    }

    /**
     * Sets the entryMain
     *
     * @param \DateTime $entryMain
     * @return void
     */
    public function setEntryMain(\DateTime $entryMain)
    {
        $this->entryMain = $entryMain;
    }

    /**
     * Returns the entryRose
     *
     * @return \DateTime $entryRose
     */
    public function getEntryRose()
    {
        return $this->entryRose;
    }

    /**
     * Sets the entryRose
     *
     * @param \DateTime $entryRose
     * @return void
     */
    public function setEntryRose(\DateTime $entryRose)
    {
        $this->entryRose = $entryRose;
    }

    /**
     * Returns the entryPrag
     *
     * @return \DateTime $entryPrag
     */
    public function getEntryPrag()
    {
        return $this->entryPrag;
    }

    /**
     * Sets the entryPrag
     *
     * @param \DateTime $entryPrag
     * @return void
     */
    public function setEntryPrag(\DateTime $entryPrag)
    {
        $this->entryPrag = $entryPrag;
    }

    /**
     * Returns the houseAnimal
     *
     * @return \DateTime $houseAnimal
     */
    public function getHouseAnimal()
    {
        return $this->houseAnimal;
    }

    /**
     * Sets the houseAnimal
     *
     * @param \DateTime $houseAnimal
     * @return void
     */
    public function setHouseAnimal(\DateTime $houseAnimal)
    {
        $this->houseAnimal = $houseAnimal;
    }

    /**
     * Returns the housePlant
     *
     * @return \DateTime $housePlant
     */
    public function getHousePlant()
    {
        return $this->housePlant;
    }

    /**
     * Sets the housePlant
     *
     * @param \DateTime $housePlant
     * @return void
     */
    public function setHousePlant(\DateTime $housePlant)
    {
        $this->housePlant = $housePlant;
    }

    /**
     * Returns the houseHal
     *
     * @return \DateTime $houseHal
     */
    public function getHouseHal()
    {
        return $this->houseHal;
    }

    /**
     * Sets the houseHal
     *
     * @param \DateTime $houseHal
     * @return void
     */
    public function setHouseHal(\DateTime $houseHal)
    {
        $this->houseHal = $houseHal;
    }

    /**
     * Returns the monthClosing
     *
     * @return \DateTime $monthClosing
     */
    public function getMonthClosing()
    {
        return $this->monthClosing;
    }

    /**
     * Sets the monthClosing
     *
     * @param \DateTime $monthClosing
     * @return void
     */
    public function setMonthClosing(\DateTime $monthClosing)
    {
        $this->monthClosing = $monthClosing;
    }

    /**
     * Returns the monthEntryInfo
     *
     * @return string $monthEntryInfo
     */
    public function getMonthEntryInfo()
    {
        return $this->monthEntryInfo;
    }

    /**
     * Sets the monthEntryInfo
     *
     * @param string $monthEntryInfo
     * @return void
     */
    public function setMonthEntryInfo($monthEntryInfo)
    {
        $this->monthEntryInfo = $monthEntryInfo;
    }

    /**
     * Adds a MonthEntryTime
     *
     * @param \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime $monthEntryTime
     * @return void
     */
    public function addMonthEntryTime(\Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime $monthEntryTime)
    {
        $this->monthEntryTime->attach($monthEntryTime);
    }

    /**
     * Removes a MonthEntryTime
     *
     * @param \Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime $monthEntryTimeToRemove The MonthEntryTime to be removed
     * @return void
     */
    public function removeMonthEntryTime(\Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime $monthEntryTimeToRemove)
    {
        $this->monthEntryTime->detach($monthEntryTimeToRemove);
    }

    /**
     * Returns the monthEntryTime
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime> $monthEntryTime
     */
    public function getMonthEntryTime()
    {
        return $this->monthEntryTime;
    }

    /**
     * Sets the monthEntryTime
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Brettingham\TbsTimePlanning\Domain\Model\MonthEntryTime> $monthEntryTime
     * @return void
     */
    public function setMonthEntryTime(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $monthEntryTime)
    {
        $this->monthEntryTime = $monthEntryTime;
    }
}
